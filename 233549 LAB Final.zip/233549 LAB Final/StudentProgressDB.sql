
CREATE DATABASE StudentProgressDB;
GO

USE StudentProgressDB;
GO
CREATE TABLE Students (
    StudentID INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(100) NOT NULL,
    Grade NVARCHAR(10) NOT NULL,
    Subject NVARCHAR(50) NOT NULL,
    Marks INT CHECK (Marks BETWEEN 0 AND 100),
    AttendancePercentage FLOAT CHECK (AttendancePercentage BETWEEN 0 AND 100),
    CreatedAt DATETIME DEFAULT GETDATE()
);
CREATE TABLE Grades (
    GradeID INT PRIMARY KEY IDENTITY(1,1),
    Grade NVARCHAR(10) NOT NULL UNIQUE
);


CREATE TABLE Subjects (
    SubjectID INT PRIMARY KEY IDENTITY(1,1),
    Subject NVARCHAR(50) NOT NULL UNIQUE
);
CREATE TABLE Attendance (
    AttendanceID INT PRIMARY KEY IDENTITY(1,1),
    StudentID INT FOREIGN KEY REFERENCES Students(StudentID) ON DELETE CASCADE,
    AttendanceDate DATE NOT NULL,
    Status NVARCHAR(10) CHECK (Status IN ('Present', 'Absent', 'Leave'))
);


INSERT INTO Grades (Grade) VALUES 
('A'), 
('B'), 
('C'), 
('D');


INSERT INTO Subjects (Subject) VALUES 
('Math'), 
('Science'), 
('History'), 
('English');


INSERT INTO Students (Name, Grade, Subject, Marks, AttendancePercentage)
VALUES 
('Ali', 'A', 'Math', 95, 98.5),
('Fahad', 'B', 'Science', 88, 89.0),
('Sami', 'A', 'History', 91, 94.0);


INSERT INTO Attendance (StudentID, AttendanceDate, Status)
VALUES 
(1, '2024-06-01', 'Present'),
(2, '2024-06-01', 'Absent'),
(3, '2024-06-01', 'Leave');

select * from Attendance;

