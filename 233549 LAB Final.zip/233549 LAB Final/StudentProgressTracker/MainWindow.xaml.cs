﻿using System;
using System.Data;
using Microsoft.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace StudentProgressTracker
{
    public partial class MainWindow : Window
    {
        // Connection string to your database
        private readonly string connectionString = "Data Source=DESKTOP-OMJLSNU;Initial Catalog=StudentProgressDB;Integrated Security=True;Trust Server Certificate=True";

        public MainWindow()
        {
            InitializeComponent();
            LoadStudents();
        }

        // Load students into the DataGrid
        private void LoadStudents()
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM Students", connection);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    StudentDataGrid.ItemsSource = dataTable.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading data: {ex.Message}");
            }
        }

        // Add a new student
        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string name = NameTextBox.Text;
                string grade = ((ComboBoxItem)GradeComboBox.SelectedItem)?.Content.ToString();
                string subject = ((ComboBoxItem)SubjectComboBox.SelectedItem)?.Content.ToString();
                int marks = int.Parse(MarksTextBox.Text);
                float attendance = float.Parse(AttendanceTextBox.Text);

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "INSERT INTO Students (Name, Grade, Subject, Marks, AttendancePercentage) VALUES (@Name, @Grade, @Subject, @Marks, @Attendance)";
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Name", name);
                    command.Parameters.AddWithValue("@Grade", grade);
                    command.Parameters.AddWithValue("@Subject", subject);
                    command.Parameters.AddWithValue("@Marks", marks);
                    command.Parameters.AddWithValue("@Attendance", attendance);
                    command.ExecuteNonQuery();
                }
                LoadStudents();
                StatusBarText.Text = "Student added successfully.";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error adding student: {ex.Message}");
            }
        }

        // Update selected student
        private void UpdateButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (StudentDataGrid.SelectedItem is DataRowView row)
                {
                    int studentId = (int)row["StudentID"];
                    string name = NameTextBox.Text;
                    string grade = ((ComboBoxItem)GradeComboBox.SelectedItem)?.Content.ToString();
                    string subject = ((ComboBoxItem)SubjectComboBox.SelectedItem)?.Content.ToString();
                    int marks = int.Parse(MarksTextBox.Text);
                    float attendance = float.Parse(AttendanceTextBox.Text);

                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "UPDATE Students SET Name = @Name, Grade = @Grade, Subject = @Subject, Marks = @Marks, AttendancePercentage = @Attendance WHERE StudentID = @StudentID";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@StudentID", studentId);
                        command.Parameters.AddWithValue("@Name", name);
                        command.Parameters.AddWithValue("@Grade", grade);
                        command.Parameters.AddWithValue("@Subject", subject);
                        command.Parameters.AddWithValue("@Marks", marks);
                        command.Parameters.AddWithValue("@Attendance", attendance);
                        command.ExecuteNonQuery();
                    }
                    LoadStudents();
                    StatusBarText.Text = "Student updated successfully.";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating student: {ex.Message}");
            }
        }

        // Delete selected student
        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (StudentDataGrid.SelectedItem is DataRowView row)
                {
                    int studentId = (int)row["StudentID"];
                    using (SqlConnection connection = new SqlConnection(connectionString))
                    {
                        connection.Open();
                        string query = "DELETE FROM Students WHERE StudentID = @StudentID";
                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@StudentID", studentId);
                        command.ExecuteNonQuery();
                    }
                    LoadStudents();
                    StatusBarText.Text = "Student deleted successfully.";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error deleting student: {ex.Message}");
            }
        }

        // Filter students by name
        private void FilterButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string filterName = NameTextBox.Text;

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT * FROM Students WHERE Name LIKE @FilterName";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    adapter.SelectCommand.Parameters.AddWithValue("@FilterName", $"%{filterName}%");
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);
                    StudentDataGrid.ItemsSource = dataTable.DefaultView;
                }
                StatusBarText.Text = "Filter applied.";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error filtering data: {ex.Message}");
            }
        }
    }
}
